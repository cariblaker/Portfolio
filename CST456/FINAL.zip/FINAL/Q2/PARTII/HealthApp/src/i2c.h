#ifndef I2C_H
#define I2C_H

#include <stdint.h>

uint16_t i2c_readBuffer(uint8_t BufferAddress);

#endif // I2C_H
