#ifndef _FOO_H
#define _FOO_H

    #include <stdint.h>
    
    // Function prototype.
    uint16_t squareNumber (uint8_t numberToBeSquared);

#endif // _FOO_H
